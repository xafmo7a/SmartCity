package Building;

public enum BuildingType {
RESIDENTIAL , INSTENTIAL , BUSINESS, INDUSTRIAL;
}
