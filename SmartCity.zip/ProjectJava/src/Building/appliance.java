package Building;

public enum appliance {
AC, HEATER,TV,FRIDGE,DRYER,WASHINGMACHINE;
}
